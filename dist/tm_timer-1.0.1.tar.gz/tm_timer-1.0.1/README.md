# In The Name of God

## tm ⏱ Terminal Timer

Minimalistic Terminal-based timer.

## Install

```bash
pip install git+https://github.com/Ph4nt01/timer.git
```

## Usage

```bash
tm 10s
tm 25m
tm 1h30m45s

p — Pause/Resume
q — Quit early

```

